﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataLayer
{
    public class Category
    {
        [Key]
        public int CategoryId { get; set; }

        [Column(TypeName ="varchar(50)")]
        [Required]
        public string Name { get; set; }
    }
}
