﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace DataLayer
{
    public class DatabaseContext : IdentityDbContext<User, Role, int>
    {
        //only for migration
        public DatabaseContext()
        {

        }

        //setting form startup.cs file
        public DatabaseContext(DbContextOptions<DatabaseContext> options): base(options)
        {

        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }

        public Product usp_getproduct(int ProductId)
        {
            Product product = new Product();
            using (var command=Database.GetDbConnection().CreateCommand())
            {
                command.CommandText = "usp_getproduct";
                command.CommandType = CommandType.StoredProcedure;

                var parameter = new SqlParameter("ProductId", ProductId);
                command.Parameters.Add(parameter);
                Database.OpenConnection();
                using (var reader= command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        product.ProductId = reader.GetInt32("ProductId");
                        product.Name = reader.GetString("Name");
                        product.Description = reader.GetString("Description");
                        product.CategoryId = reader.GetInt32("CategoryId");
                    }
                }
                Database.CloseConnection();
            }
            return product;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //migration purpose
                optionsBuilder.UseSqlServer("data source=Shailendra\\SqlExpress; initial catalog=CSMProject;persist security info=True;user id=sa;password=dotnettricks;");
            }
            base.OnConfiguring(optionsBuilder);
        }
    }
}
