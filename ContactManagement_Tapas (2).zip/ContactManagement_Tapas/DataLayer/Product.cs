﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataLayer
{
   // [Index(nameof(Name), nameof(ProductId), Name = "ix_name", IsUnique = true)]
    public class Product
    {
        public Product()
        {
            Name = "Tapas";
        }

        [Key]
        public int ProductId { get; set; }

        [Column(TypeName = "varchar(250)")]
        [Required]
        public string Name { get; set; }

        [Column(TypeName = "varchar(250)")]
        [Required]
        public string Description { get; set; }

        [ForeignKey("Category")]
        public int CategoryId { get; set; }
        public Category Category { get; set; }
    }
}
