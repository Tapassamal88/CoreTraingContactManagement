﻿using DataLayer;
using Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public interface IUnitOfWork
    {
        IProductRepository ProductRepo { get; }
        IRepository<Category> CategoryRepo { get; }
        int SaveChanges();
    }
}
