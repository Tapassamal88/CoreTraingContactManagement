﻿using DataLayer;
using Microsoft.EntityFrameworkCore;
using Repositories.Interfaces;
using Repositories.Models;
using System.Collections.Generic;
using System.Linq;
using X.PagedList;

namespace Repositories.Implementations
{
    public class ProductRepository : Repository<Product>, IProductRepository
    {
        public DatabaseContext context
        {
            get
            {
                return _dbContext as DatabaseContext;
            }
        }
        public ProductRepository(DbContext _db) : base(_db)
        {

        }

        public PagingModel<ProductModel> GetProducts(int page, int pageSize)
        {
            var data = (from prd in context.Products
                        join cat in context.Categories
                        on prd.CategoryId equals cat.CategoryId
                        orderby prd.ProductId
                        select new ProductModel
                        {
                            ProductId = prd.ProductId,
                            Name = prd.Name,
                            Description = prd.Description,
                            Category = cat.Name
                        });

            //deferred execution and immediate execution


            int count = data.Count(); //1
            var dataList = data.Skip((page - 1) * pageSize).Take(pageSize).ToList(); //2

            PagingModel<ProductModel> model = new PagingModel<ProductModel>();
            if (dataList.Count > 0)
            {
                model.Data = new StaticPagedList<ProductModel>(dataList, page, pageSize, count);
                model.Page = page;
                model.PageSize = pageSize;
                model.TotalPages = count;
            }
            return model;
        }

        public Product GetProductBySp(int ProductId)
        {
            return context.usp_getproduct(ProductId);
        }
    }
}
