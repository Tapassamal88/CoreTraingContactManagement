﻿using DataLayer;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.Interfaces
{
    public interface IProductRepository : IRepository<Product>
    {
        PagingModel<ProductModel> GetProducts(int page, int pageSize);
        Product GetProductBySp(int ProductId);
    }
}
